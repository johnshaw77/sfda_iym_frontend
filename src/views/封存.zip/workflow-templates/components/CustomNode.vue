<template>
  <div
    :class="[
      'min-w-[180px] bg-white rounded-lg border shadow-md transition-shadow hover:shadow-lg relative',
      selected ? 'ring-2 ring-blue-500' : '',
    ]"
  >
    <!-- 頂部標題欄 -->
    <div
      :class="[
        'px-4 py-2 rounded-t-lg border-b flex items-center space-x-2',
        headerClasses[data.type] || '',
      ]"
    >
      <component
        :is="data.icon"
        :class="iconClasses[data.type] || ''"
        :size="18"
      />
      <span class="font-medium text-sm">{{ data.label }}</span>
    </div>

    <!-- 內容區域 -->
    <div class="p-3 space-y-2">
      <!-- 這裡可以添加節點的配置項 -->
      <div class="text-xs text-gray-500">
        狀態：{{ getStatusText(data.status) }}
      </div>
    </div>

    <!-- 連接點 -->
    <!-- 頂部連接點 -->
    <Handle
      type="target"
      position="top"
      :class="['!absolute', handleClasses[data.type] || '']"
      :style="{ left: '50%', top: '-5px', transform: 'translateX(-50%)' }"
    />
    <!-- 底部連接點 -->
    <Handle
      type="source"
      position="bottom"
      :class="['!absolute', handleClasses[data.type] || '']"
      :style="{ left: '50%', bottom: '-5px', transform: 'translateX(-50%)' }"
    />
    <!-- 左側連接點 -->
    <Handle
      type="target"
      position="left"
      :class="['!absolute', handleClasses[data.type] || '']"
      :style="{ left: '-5px', top: '50%', transform: 'translateY(-50%)' }"
    />
    <!-- 右側連接點 -->
    <Handle
      type="source"
      position="right"
      :class="['!absolute', handleClasses[data.type] || '']"
      :style="{ right: '-5px', top: '50%', transform: 'translateY(-50%)' }"
    />
  </div>
</template>

<script setup>
import { computed } from "vue";
import { Handle } from "@vue-flow/core";
import {
  FileInput,
  Database,
  Filter,
  Calculator,
  ChartBar,
  FileOutput,
  Table,
} from "lucide-vue-next";

const props = defineProps({
  id: {
    type: String,
    required: true,
  },
  data: {
    type: Object,
    required: true,
  },
  selected: {
    type: Boolean,
    default: false,
  },
});

// 頂部標題欄樣式
const headerClasses = {
  dataInput: "bg-blue-50 border-blue-100",
  dataProcess: "bg-green-50 border-green-100",
  dataOutput: "bg-purple-50 border-purple-100",
};

// 圖標顏色
const iconClasses = {
  dataInput: "text-blue-600",
  dataProcess: "text-green-600",
  dataOutput: "text-purple-600",
};

// 連接點樣式
const handleClasses = {
  dataInput: "!bg-blue-500 hover:!bg-blue-600",
  dataProcess: "!bg-green-500 hover:!bg-green-600",
  dataOutput: "!bg-purple-500 hover:!bg-purple-600",
};

// 獲取狀態文字
const getStatusText = (status) => {
  const statusMap = {
    idle: "待執行",
    running: "執行中",
    completed: "已完成",
    error: "錯誤",
  };
  return statusMap[status] || status;
};

// 處理節點點擊
const handleNodeClick = () => {
  // 觸發節點選中事件
  // 這裡可以通過 emit 事件或其他方式通知父組件
};
</script>

<style scoped>
/* 連接點基本樣式 */
:deep(.vue-flow__handle) {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  border: 2px solid white;
  transition: all 0.2s ease;
}

:deep(.vue-flow__handle:hover) {
  transform: scale(1.2);
}

/* 為連接線添加箭頭 */
:deep(.vue-flow__edge-path) {
  stroke-width: 2;
  marker-end: url(#vue-flow__arrowhead);
}

/* 定義箭頭樣式 */
:deep(.vue-flow__edge) {
  path {
    stroke: #b1b1b7;
  }
  &.selected {
    path {
      stroke: #1976d2;
    }
  }
  &:hover {
    path {
      stroke: #1976d2;
    }
  }
}

/* 添加箭頭定義 */
:deep(#vue-flow__arrowhead) {
  fill: #b1b1b7;
}

:deep(.vue-flow__edge.selected #vue-flow__arrowhead),
:deep(.vue-flow__edge:hover #vue-flow__arrowhead) {
  fill: #1976d2;
}
</style>

export const EDGE_TYPES = {
  STEP: "step",
  SMOOTH: "smoothstep",
  STRAIGHT: "straight",
  CUSTOM: "custom",
  DEFAULT: "",
};
